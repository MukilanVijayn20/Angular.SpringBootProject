export class Product
{
    constructor(
        public id:number,
        public course_name:string,
        public course_des:string,
        public course_fees:number,
        public image :string,
        public cfile : string

    ){}
}