export class Feedback
{
    constructor(
        public id:number,
        public user_name:string,
        public user_email:string,
        public subject:string,
        public message:string

    ){}
}
