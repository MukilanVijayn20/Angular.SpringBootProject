export class Register {
    id: number;
    firstname: string;
    lastname: string;
     dob:Date;
     gender: string;
     phone:number;
     username:string;
     email:string;
     password:string;
     confirmpassword:string;

}
