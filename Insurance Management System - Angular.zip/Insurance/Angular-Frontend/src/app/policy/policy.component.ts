import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent   {

  public categories = ['Maximum Lump Sum Withdrawal', 'Minimum term', 'Flexibility','Freedom to choose annuity provider','Direct premium payment','Extended Revival for ULIPs'];
  public MaximumLumpSumWithdrawl = [ 'Select ','One Third','60%'];
  public MinimumTerm = [ 'Select ','3 years','2 years'];
  public Flexibility = ['Select Minimum 10 times for those under 45','Guarantee meant insures had to invest in debt products'];
  public FreedomToChooseAnnunityProvider = ['Select Minimum 10 times for those under 45','Annuity to be purchased from the insurer who has issued deferred pension plan'];
  public DirectPremiumPayment = ['Select Minimum 10 times for those under 45','Premiums for riders like accident or benefit accounted for by cancelling units'];
  public ExtendedRevivalForULIPs = ['Select Minimum 10 times for those under 45','2 years'];

  public data = [
   {LifeCoverinULIPs: 'MaximumLumpSumWithdrawal'},
   { Minimum10timesforthoseunder45: 'OneThird'},

   { Minimum7timesforthoseunder451: '60%'},
   { Minimum10timesforthoseunder451: '3 years'},
   { Minimum7timesforthoseunder451: '2 years'},

 
   {Name:'Guarantee meant insures had to invest in debt products'},
   {Name:'Annuity to be purchased from the insurer who has issued deferred pension plan'},
   {Name:'Premiums for riders like accident or benefit accounted for by cancelling units'},
   {Name:'2 years'},
  
  ];
  public products:any = [];
  public selectedCategoryName = 'Select a Category';
  public selectedProductName:any;
  public selectedProductName1:any;
  public searchResults:any = [];
  public searchedProduct:any = {
    LifeCoverinULIPs:'MaximumLumpSumWithdrawal',
    Minimum10timesforthoseunder45:'OneThird',
    Minimum7timesforthoseunder45:'60%',
    Minimum7timesforthoseunder4511:'3 years',
    Minimum10timesforthoseunder451:'2 years',


    
  };
  public cartItems:any = [];
  public cartItemsCount = 0;
  public showCart = false;
  public GetCartItemsCount(){
    this.cartItemsCount = this.cartItems.length;
  }
  public OnCategoryChange(){
    switch(this.selectedCategoryName)
    {
      case 'Maximum Lump Sum Withdrawal':
        this.products = this.MaximumLumpSumWithdrawl;
        break;
       
       
      case 'Minimum term':
        this.products = this.MinimumTerm;
        break;
      case 'Flexibility':
        this.products = this.Flexibility;
        break;
        case 'Freedom to choose annuity provider':
          this.products = this.FreedomToChooseAnnunityProvider;
          break;
          case 'Direct premium payment':
            this.products = this.DirectPremiumPayment;
            break;
            case 'Extended Revival for ULIPs':
              this.products = this.ExtendedRevivalForULIPs;
              break;
                    
      default:
        this.products = ['Select a Category'];
        break;
    }
  }
  public onProductChanged(){
      this.searchResults = this.data.filter(x=>x.LifeCoverinULIPs==this.selectedProductName);
      this.searchedProduct = {
        LifeCoverinULIPs: this.searchResults[0].LifeCoverinULIPs,
       Minimum10timesforthoseunder45: this.searchResults[0].Minimum7timesforthoseunder45,
       
      };
  }
  public AddToCartClick() {
     this.cartItems.push(this.searchedProduct);
     alert('Policy Added');
     this.GetCartItemsCount();
  }
  public ToggleCartDisplay() {
    this.showCart = (this.showCart==false)?true:false;
  }
  public DeleteCartItem(index:any){
     let confirmDelete = confirm('Are you sure, want to Delete?');
     if(confirmDelete==true) {
       this.cartItems.splice(index, 1);
       this.GetCartItemsCount();
     }
  }
 }

